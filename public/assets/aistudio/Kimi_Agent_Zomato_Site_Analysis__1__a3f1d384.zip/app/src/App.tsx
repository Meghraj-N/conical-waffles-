import { useEffect, useMemo, useRef, useState } from 'react'
import * as Dialog from '@radix-ui/react-dialog'
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Clock3,
  IceCreamBowl,
  Instagram,
  MapPin,
  Menu as MenuIcon,
  Minus,
  Navigation,
  Phone,
  Plus,
  Search,
  ShoppingBag,
  Sparkles,
  Star,
  X,
} from 'lucide-react'
import './App.css'

type Category = 'Chocolate' | 'Fruity' | 'Classics'
type Size = { name: string; price: number }
type Product = {
  id: number
  name: string
  description: string
  image: string
  category: Category
  sizes: Size[]
  badge?: string
  tone: string
  featured?: boolean
}
type CartItem = { key: string; product: Product; size: Size; quantity: number }
type Offer = { title: string; subtitle: string; detail: string; label: string }

const waffleSizes = (price: number): Size[] => [
  { name: 'Regular', price },
  { name: 'Large', price: price + 40 },
  { name: 'Mini box', price: price + 70 },
]

const products: Product[] = [
  {
    id: 1,
    name: 'Dark & White Delight',
    description: 'Crisp waffle, dark chocolate and silky white drizzle.',
    image: '/images/dark-white-delight.webp',
    category: 'Chocolate',
    sizes: waffleSizes(70),
    badge: 'Bestseller',
    tone: 'cocoa',
    featured: true,
  },
  {
    id: 2,
    name: 'Oreo Cookie Delight',
    description: 'Chocolate, cream and a generous Oreo crumble.',
    image: '/images/oreo-cookie-delight.webp',
    category: 'Chocolate',
    sizes: waffleSizes(110),
    badge: 'Crowd favourite',
    tone: 'oreo',
  },
  {
    id: 3,
    name: 'Strawberry Surprise',
    description: 'Sweet cream with a bright strawberry swirl.',
    image: '/images/strawberry-surprise.webp',
    category: 'Fruity',
    sizes: waffleSizes(120),
    tone: 'berry',
  },
  {
    id: 4,
    name: 'Triple Chocolate',
    description: 'Three layers of deep, decadent chocolate.',
    image: '/images/waffle-0022.webp',
    category: 'Chocolate',
    sizes: waffleSizes(90),
    tone: 'caramel',
  },
  {
    id: 5,
    name: 'Lotus Biscoff',
    description: 'Caramelised Biscoff spread and cookie crunch.',
    image: '/images/hero-waffle.webp',
    category: 'Classics',
    sizes: waffleSizes(140),
    badge: 'Signature',
    tone: 'biscoff',
  },
  {
    id: 6,
    name: 'Berry Bliss',
    description: 'Dark chocolate, berries and a playful crunch.',
    image: '/images/waffle-04.webp',
    category: 'Fruity',
    sizes: waffleSizes(130),
    tone: 'berry',
  },
  {
    id: 7,
    name: 'Rainbow Surprise',
    description: 'A crisp classic finished with colourful sprinkles.',
    image: '/images/rainbow-surprise.webp',
    category: 'Classics',
    sizes: waffleSizes(120),
    tone: 'vanilla',
  },
  {
    id: 8,
    name: 'Slow-Churned Gelato',
    description: 'Creamy, slow-churned scoops made for waffle pairing.',
    image: '/images/gelato.webp',
    category: 'Classics',
    sizes: [
      { name: 'Single scoop', price: 99 },
      { name: 'Double scoop', price: 149 },
      { name: 'Waffle sundae', price: 189 },
    ],
    tone: 'pistachio',
  },
]

const offers: Offer[] = [
  {
    label: 'Instant offer',
    title: 'Flat 10% off',
    subtitle: 'on dining bill payments',
    detail: 'Visit the Kandivali West store and ask about the instant dining offer when paying your bill. Final eligibility and availability are confirmed by the store.',
  },
  {
    label: 'A little extra joy',
    title: 'A scratch card',
    subtitle: 'after every eligible transaction',
    detail: 'Ask the store team about the current scratch-card promotion after your dining transaction. Surprise rewards and eligibility are subject to the live store offer.',
  },
  {
    label: 'Next visit treat',
    title: 'Flat ₹175 off',
    subtitle: 'on your next dining payment',
    detail: 'This is a next-visit dining offer. Ask the Kandivali West team how to redeem it and whether your visit qualifies before placing your order.',
  },
]

const formatPrice = (price: number) => `₹${price}`

export default function App() {
  const [category, setCategory] = useState<'All' | Category>('All')
  const [selectedSizes, setSelectedSizes] = useState<Record<number, number>>({})
  const [cart, setCart] = useState<CartItem[]>([])
  const [cartOpen, setCartOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [orderOpen, setOrderOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [activeProduct, setActiveProduct] = useState<Product | null>(null)
  const [modalSize, setModalSize] = useState(0)
  const [activeOffer, setActiveOffer] = useState<Offer | null>(null)
  const [notice, setNotice] = useState('')
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const filteredProducts = useMemo(
    () => products.filter((product) => category === 'All' || product.category === category),
    [category],
  )
  const searchResults = useMemo(() => {
    const term = query.trim().toLowerCase()
    if (!term) return products.slice(0, 5)
    return products.filter((product) =>
      `${product.name} ${product.description} ${product.category}`.toLowerCase().includes(term),
    )
  }, [query])
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0)
  const subtotal = cart.reduce((sum, item) => sum + item.size.price * item.quantity, 0)

  useEffect(() => {
    let frame = 0
    const update = () => {
      frame = 0
      const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
      const shift = reduced ? 0 : Math.min(window.scrollY, 700) * 0.09
      document.documentElement.style.setProperty('--hero-shift', `${shift}px`)
    }
    const onScroll = () => {
      if (!frame) frame = window.requestAnimationFrame(update)
    }
    update()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => {
      window.removeEventListener('scroll', onScroll)
      if (frame) window.cancelAnimationFrame(frame)
    }
  }, [])

  const showNotice = (message: string) => {
    setNotice(message)
    if (noticeTimer.current) clearTimeout(noticeTimer.current)
    noticeTimer.current = setTimeout(() => setNotice(''), 2800)
  }

  const addToCart = (product: Product, sizeIndex: number) => {
    const size = product.sizes[sizeIndex]
    const key = `${product.id}-${size.name}`
    setCart((current) => {
      const existing = current.find((item) => item.key === key)
      if (existing) {
        return current.map((item) => item.key === key ? { ...item, quantity: item.quantity + 1 } : item)
      }
      return [...current, { key, product, size, quantity: 1 }]
    })
    showNotice(`${product.name} · ${size.name} added to your bag`)
  }

  const changeQuantity = (key: string, delta: number) => {
    setCart((current) => current
      .map((item) => item.key === key ? { ...item, quantity: item.quantity + delta } : item)
      .filter((item) => item.quantity > 0))
  }

  const previewProduct = (product: Product) => {
    setModalSize(selectedSizes[product.id] ?? 0)
    setActiveProduct(product)
  }

  const closeMobileAndScroll = () => setMenuOpen(false)

  return (
    <div className="site-shell">
      <a className="skip-link" href="#main">Skip to content</a>

      <div className="announcement">
        <a href="#wednesday">Wednesday just got sweeter — buy one, get one free <ArrowRight size={14} /></a>
        <span className="announcement-location"><MapPin size={13} /> Kandivali West</span>
      </div>

      <header className="site-header glass-dark">
        <a className="wordmark" href="#top" aria-label="Conical Gaufres home">
          <IceCreamBowl size={25} strokeWidth={1.7} />
          <span>CONICAL <strong>GAUFRES</strong></span>
        </a>
        <nav className="desktop-nav" aria-label="Main navigation">
          <a href="#menu">Menu</a>
          <a href="#offers">Offers</a>
          <a href="#wednesday">Wednesday sale</a>
          <a href="#story">Our story</a>
        </nav>
        <div className="header-actions">
          <button className="icon-button search-trigger" onClick={() => setSearchOpen(true)} aria-label="Search desserts">
            <Search size={19} />
          </button>
          <a className="location-link" href="#visit"><MapPin size={17} /><span>Kandivali West</span></a>
          <button className="bag-button" onClick={() => setCartOpen(true)} aria-label={`Open bag with ${cartCount} items`}>
            <ShoppingBag size={18} />
            <span>Bag</span>
            <b>{cartCount}</b>
          </button>
          <button className="icon-button mobile-trigger" onClick={() => setMenuOpen(true)} aria-label="Open menu">
            <MenuIcon size={22} />
          </button>
        </div>
      </header>

      <main id="main">
        <section className="hero" id="top">
          <div className="hero-glow hero-glow-one" />
          <div className="hero-glow hero-glow-two" />
          <div className="hero-copy">
            <p className="eyebrow"><Sparkles size={15} /> Handcrafted happiness · Since 2017</p>
            <h1>A little joy.<br /><em>On a stick.</em></h1>
            <p className="hero-description">Crisp golden waffles, slow-churned gelato and unapologetically generous chocolate. Made fresh for your sweetest moments.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#menu">Order your favourite <ArrowRight size={18} /></a>
              <button className="text-link" onClick={() => previewProduct(products[0])}>Meet the bestseller <ArrowUpRight size={17} /></button>
            </div>
            <div className="hero-proof">
              <span><Star size={16} fill="currentColor" /> <strong>4.4</strong> on Zomato</span>
              <span>Pure vegetarian</span>
              <span>Made to order</span>
            </div>
          </div>

          <div className="hero-visual" aria-label="Lotus Biscoff signature stick waffle">
            <div className="orbit orbit-one" />
            <div className="orbit orbit-two" />
            <span className="hero-word" aria-hidden="true">GAUFRES</span>
            <img className="hero-product" src="/images/hero-waffle.webp" alt="Signature Conical Gaufres stick waffle with caramel and chocolate" />
            <div className="floating-note floating-note-top glass-dark">
              <span>Signature crunch</span>
              <strong>Lotus Biscoff</strong>
              <small>Caramel · cookie · chocolate</small>
            </div>
            <div className="floating-note floating-note-bottom glass-dark">
              <span className="rating-dot"><Star size={14} fill="currentColor" /></span>
              <div><strong>Loved in Mumbai</strong><small>1,300+ delivery ratings</small></div>
            </div>
          </div>
          <a className="scroll-cue" href="#menu"><span>Discover the menu</span><ChevronDown size={17} /></a>
        </section>

        <div className="flavour-ribbon" aria-label="Store highlights">
          <span>STICK WAFFLES</span><i />
          <span>SLOW-CHURNED GELATO</span><i />
          <span>THICK SHAKES</span><i />
          <span>MINI WAFFLES</span><i />
          <span>FRESHLY MADE</span>
        </div>

        <section className="products-section" id="menu">
          <div className="section-heading light-heading">
            <div>
              <p className="eyebrow">The dessert edit</p>
              <h2>Pick your<br /><em>happy place.</em></h2>
            </div>
            <div className="menu-intro">
              <p>From chocolate-heavy classics to bright berry creations, every waffle is made fresh and finished by hand.</p>
              <div className="filter-row" aria-label="Filter desserts by flavour">
                {(['All', 'Chocolate', 'Fruity', 'Classics'] as const).map((item) => (
                  <button key={item} className={category === item ? 'filter active' : 'filter'} onClick={() => setCategory(item)} aria-pressed={category === item}>
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="product-grid">
            {filteredProducts.map((product) => {
              const selected = Math.min(selectedSizes[product.id] ?? 0, product.sizes.length - 1)
              return (
                <article className={`product-card glass-light ${product.featured && category === 'All' ? 'featured' : ''} ${product.id === 8 ? 'gelato-card' : ''}`} key={product.id}>
                  <div className={`product-image-wrap ${product.tone}`}>
                    {product.badge && <span className="product-badge">{product.badge}</span>}
                    <button className="product-preview" onClick={() => previewProduct(product)} aria-label={`View ${product.name} details`}>
                      <img src={product.image} alt={product.name} loading="lazy" />
                    </button>
                    <button className="quick-view" onClick={() => previewProduct(product)} aria-label={`Quick view ${product.name}`}><ArrowUpRight size={19} /></button>
                  </div>
                  <div className="product-info">
                    <button className="product-name" onClick={() => previewProduct(product)}>{product.name}</button>
                    <p>{product.description}</p>
                    <div className="size-label"><span>Choose a size</span><span>{product.sizes[selected].name}</span></div>
                    <div className="size-options" aria-label={`Sizes for ${product.name}`}>
                      {product.sizes.map((size, index) => (
                        <button key={size.name} className={selected === index ? 'selected' : ''} onClick={() => setSelectedSizes((current) => ({ ...current, [product.id]: index }))} aria-pressed={selected === index}>
                          {size.name}
                        </button>
                      ))}
                    </div>
                    <div className="product-bottom">
                      <strong>{formatPrice(product.sizes[selected].price)}</strong>
                      <button className="add-button" onClick={() => addToCart(product, selected)}>Add to bag <Plus size={17} /></button>
                    </div>
                  </div>
                </article>
              )
            })}
          </div>
        </section>

        <section className="offers-section" id="offers">
          <div className="section-heading dark-heading compact-heading">
            <div>
              <p className="eyebrow">A sweeter bill</p>
              <h2>Offers worth<br /><em>stepping out for.</em></h2>
            </div>
            <p>Dining perks for your next visit to Mahavir Nagar. Tap an offer to see exactly how to redeem it.</p>
          </div>
          <div className="offer-grid">
            {offers.map((offer, index) => (
              <article className={`offer-card glass-dark offer-${index + 1}`} key={offer.title}>
                <span className="offer-label">{offer.label}</span>
                <div>
                  <h3>{offer.title}</h3>
                  <p>{offer.subtitle}</p>
                </div>
                <button className="offer-link" onClick={() => setActiveOffer(offer)}>How to redeem <ArrowUpRight size={18} /></button>
              </article>
            ))}
          </div>
          <p className="offer-note">Offers are subject to store availability and eligibility. Confirm with the team before ordering.</p>
        </section>

        <section className="wednesday-section" id="wednesday">
          <div className="wednesday-copy">
            <p className="eyebrow">Every Wednesday · In store</p>
            <h2>One for you.<br /><em>One on us.</em></h2>
            <p>Make midweek the best day of the week. Buy one waffle and get another free at Conical Gaufres every Wednesday.</p>
            <a className="button button-cream" href="#menu">Choose your two <ArrowRight size={18} /></a>
            <small>Visit the store to confirm eligible waffles and offer availability.</small>
          </div>
          <div className="wednesday-visual" aria-hidden="true">
            <span className="bogo-type">2<span>for</span>1</span>
            <img className="bogo-waffle bogo-one" src="/images/strawberry-surprise.webp" alt="" loading="lazy" />
            <img className="bogo-waffle bogo-two" src="/images/dark-white-delight.webp" alt="" loading="lazy" />
            <div className="bogo-stamp"><span>WEDNESDAY</span><strong>BOGO</strong><span>ALL DAY</span></div>
          </div>
        </section>

        <section className="story-section" id="story">
          <div className="story-image">
            <img src="/images/story-waffle.webp" alt="Freshly prepared chocolate waffle with chocolate pieces" loading="lazy" />
            <div className="story-caption glass-dark"><span>Our secret ingredient?</span><strong>Pure joy.</strong></div>
          </div>
          <div className="story-copy">
            <p className="eyebrow">From a cart to a craving</p>
            <h2>Made with love.<br /><em>Remembered with a smile.</em></h2>
            <p>On 15 August 2017, founders Sameer and Kshama Dave introduced their signature stick waffles from a single cart. That small dream grew into a pan-India dessert family.</p>
            <blockquote>“We turn the flavours you already love into something wonderfully new.”</blockquote>
            <div className="story-stats">
              <div><strong>120+</strong><span>outlets across India</span></div>
              <div><strong>2017</strong><span>our first sweet chapter</span></div>
              <div><strong>100%</strong><span>vegetarian kitchen</span></div>
            </div>
          </div>
        </section>

        <section className="visit-section" id="visit">
          <div className="visit-heading">
            <p className="eyebrow">Your neighbourhood dessert stop</p>
            <h2>Come by.<br /><em>Leave happier.</em></h2>
          </div>
          <div className="visit-card glass-light">
            <div className="visit-detail">
              <MapPin size={22} />
              <div><span>Find us</span><strong>Shop 28, Raj Arcade, Khau Gali,<br />Mahavir Nagar, Kandivali West, Mumbai</strong></div>
            </div>
            <div className="visit-detail">
              <Clock3 size={22} />
              <div><span>Store hours</span><strong>12:30 pm – 12 midnight<br /><small>Late-night service: 12 midnight – 12:30 am</small></strong></div>
            </div>
            <div className="visit-actions">
              <a className="button button-dark" href="https://www.google.com/maps/search/?api=1&query=Conical+Gaufres+Kandivali+West+Mumbai" target="_blank" rel="noreferrer">Get directions <Navigation size={17} /></a>
              <a className="text-link dark-link" href="tel:+919833087392"><Phone size={17} /> Call the store</a>
            </div>
          </div>
        </section>

        <section className="faq-section" aria-labelledby="faq-title">
          <div><p className="eyebrow">Good to know</p><h2 id="faq-title">Before your<br /><em>first bite.</em></h2></div>
          <div className="faq-list">
            <details><summary>Is Conical Gaufres vegetarian?<Plus size={18} /></summary><p>Yes. The Kandivali West store is vegetarian only, with waffles, gelato, shakes and other desserts on the menu.</p></details>
            <details><summary>Can I order takeaway or delivery?<Plus size={18} /></summary><p>Yes. Takeaway and home delivery are available. Use the order links below to check live availability and delivery times.</p></details>
            <details><summary>How does the Wednesday BOGO work?<Plus size={18} /></summary><p>The store advertises buy one, get one free every Wednesday. Eligible products and live offer availability should be confirmed with the store team.</p></details>
            <details><summary>Can I choose different serving sizes?<Plus size={18} /></summary><p>Use the size selector on any dessert above to preview regular, large and mini-box options. Final menu options and prices are confirmed when you order.</p></details>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-top">
          <a className="wordmark footer-logo" href="#top"><IceCreamBowl size={29} /><span>CONICAL <strong>GAUFRES</strong></span></a>
          <p>Waffles, gelato, shakes and everything else your sweet tooth craves.</p>
          <a className="button button-primary" href="https://www.zomato.com/mumbai/conical-gaufres-kandivali-west" target="_blank" rel="noreferrer">Order online <ArrowUpRight size={18} /></a>
        </div>
        <div className="footer-links">
          <div><span>Explore</span><a href="#menu">Dessert menu</a><a href="#offers">Store offers</a><a href="#wednesday">Wednesday sale</a></div>
          <div><span>Visit</span><a href="#visit">Kandivali West</a><a href="#story">Our story</a><a href="tel:+919833087392">+91 98330 87392</a></div>
          <div><span>Order & follow</span><a href="https://www.zomato.com/mumbai/conical-gaufres-kandivali-west" target="_blank" rel="noreferrer">Zomato</a><a href="https://www.swiggy.com/city/mumbai/conical-gaufres-mahavir-nagar-kandivali-west-rest500608" target="_blank" rel="noreferrer">Swiggy</a><a href="https://www.instagram.com/conicalgaufresofficial/" target="_blank" rel="noreferrer"><Instagram size={15} /> Instagram</a></div>
        </div>
        <div className="footer-bottom"><span>© 2026 Conical Gaufres. Crafted for sweet moments.</span><span>Premium dessert storefront concept · Kandivali West</span></div>
      </footer>

      <Dialog.Root open={searchOpen} onOpenChange={setSearchOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="dialog-overlay" />
          <Dialog.Content className="search-dialog glass-dark" aria-describedby={undefined}>
            <Dialog.Title className="sr-only">Search desserts</Dialog.Title>
            <div className="search-input-wrap"><Search size={22} /><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search chocolate, strawberry, gelato…" aria-label="Search desserts" /></div>
            <Dialog.Close className="dialog-close" aria-label="Close search"><X size={20} /></Dialog.Close>
            <div className="search-results">
              <span className="search-label">{query ? `${searchResults.length} matching desserts` : 'Popular right now'}</span>
              {searchResults.length ? searchResults.map((product) => (
                <button key={product.id} onClick={() => { setSearchOpen(false); previewProduct(product) }}>
                  <img src={product.image} alt="" />
                  <span><strong>{product.name}</strong><small>{product.category} · from {formatPrice(product.sizes[0].price)}</small></span>
                  <ArrowUpRight size={18} />
                </button>
              )) : <div className="empty-search"><IceCreamBowl size={28} /><strong>No desserts found</strong><p>Try “chocolate”, “berry” or “gelato”.</p></div>}
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={menuOpen} onOpenChange={setMenuOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="dialog-overlay" />
          <Dialog.Content className="mobile-menu glass-dark" aria-describedby={undefined}>
            <Dialog.Title>Where to?</Dialog.Title>
            <Dialog.Close className="dialog-close" aria-label="Close menu"><X size={22} /></Dialog.Close>
            <nav>
              <a onClick={closeMobileAndScroll} href="#menu">Dessert menu <ArrowRight size={19} /></a>
              <a onClick={closeMobileAndScroll} href="#offers">Store offers <ArrowRight size={19} /></a>
              <a onClick={closeMobileAndScroll} href="#wednesday">Wednesday sale <ArrowRight size={19} /></a>
              <a onClick={closeMobileAndScroll} href="#story">Our story <ArrowRight size={19} /></a>
              <a onClick={closeMobileAndScroll} href="#visit">Visit the store <ArrowRight size={19} /></a>
            </nav>
            <p>Pure vegetarian · Made fresh · Kandivali West</p>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={!!activeProduct} onOpenChange={(open) => { if (!open) setActiveProduct(null) }}>
        <Dialog.Portal>
          <Dialog.Overlay className="dialog-overlay" />
          {activeProduct && <Dialog.Content className="product-dialog glass-light" aria-describedby="product-dialog-description">
            <Dialog.Close className="dialog-close light-close" aria-label="Close product details"><X size={20} /></Dialog.Close>
            <div className={`dialog-product-image ${activeProduct.tone}`}><img src={activeProduct.image} alt={activeProduct.name} /></div>
            <div className="dialog-product-copy">
              <p className="eyebrow">{activeProduct.category} · Made fresh</p>
              <Dialog.Title>{activeProduct.name}</Dialog.Title>
              <p id="product-dialog-description">{activeProduct.description} Choose your preferred serving, then add it to your bag.</p>
              <span className="dialog-label">Size</span>
              <div className="dialog-sizes">
                {activeProduct.sizes.map((size, index) => <button className={modalSize === index ? 'selected' : ''} key={size.name} onClick={() => setModalSize(index)} aria-pressed={modalSize === index}><span>{size.name}</span><strong>{formatPrice(size.price)}</strong></button>)}
              </div>
              <button className="button button-dark dialog-add" onClick={() => { addToCart(activeProduct, modalSize); setActiveProduct(null); setCartOpen(true) }}>Add to bag · {formatPrice(activeProduct.sizes[modalSize].price)} <ShoppingBag size={18} /></button>
              <small className="price-disclaimer">Preview prices. Final availability and pricing are confirmed when ordering.</small>
            </div>
          </Dialog.Content>}
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={!!activeOffer} onOpenChange={(open) => { if (!open) setActiveOffer(null) }}>
        <Dialog.Portal>
          <Dialog.Overlay className="dialog-overlay" />
          {activeOffer && <Dialog.Content className="offer-dialog glass-dark" aria-describedby="offer-description">
            <Dialog.Close className="dialog-close" aria-label="Close offer"><X size={20} /></Dialog.Close>
            <span className="offer-label">{activeOffer.label}</span>
            <Dialog.Title>{activeOffer.title}</Dialog.Title>
            <h3>{activeOffer.subtitle}</h3>
            <p id="offer-description">{activeOffer.detail}</p>
            <a className="button button-cream" href="https://www.google.com/maps/search/?api=1&query=Conical+Gaufres+Kandivali+West+Mumbai" target="_blank" rel="noreferrer">Visit & redeem <Navigation size={17} /></a>
          </Dialog.Content>}
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={cartOpen} onOpenChange={setCartOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="dialog-overlay" />
          <Dialog.Content className="cart-drawer glass-light" aria-describedby="cart-description">
            <div className="cart-head"><div><span>Your sweet picks</span><Dialog.Title>Your bag <b>{cartCount}</b></Dialog.Title></div><Dialog.Close className="dialog-close light-close" aria-label="Close bag"><X size={20} /></Dialog.Close></div>
            <p id="cart-description" className="sr-only">Review your selected desserts and continue to an ordering platform.</p>
            {cart.length === 0 ? <div className="empty-cart"><ShoppingBag size={34} strokeWidth={1.4} /><h3>Your bag is craving something.</h3><p>Pick a waffle, choose a size and make it yours.</p><Dialog.Close asChild><a className="button button-dark" href="#menu">Browse the menu <ArrowRight size={17} /></a></Dialog.Close></div> : <>
              <div className="cart-items">
                {cart.map((item) => <div className="cart-item" key={item.key}>
                  <div className={`cart-thumb ${item.product.tone}`}><img src={item.product.image} alt="" /></div>
                  <div className="cart-item-copy"><strong>{item.product.name}</strong><span>{item.size.name} · {formatPrice(item.size.price)}</span><div className="quantity-control"><button onClick={() => changeQuantity(item.key, -1)} aria-label={`Remove one ${item.product.name}`}><Minus size={14} /></button><span>{item.quantity}</span><button onClick={() => changeQuantity(item.key, 1)} aria-label={`Add one more ${item.product.name}`}><Plus size={14} /></button></div></div>
                  <strong>{formatPrice(item.size.price * item.quantity)}</strong>
                </div>)}
              </div>
              <div className="cart-summary"><div><span>Subtotal</span><strong>{formatPrice(subtotal)}</strong></div><p>Taxes and delivery charges are calculated on the ordering platform.</p><button className="button button-dark" onClick={() => { setCartOpen(false); setOrderOpen(true) }}>Continue to order <ArrowRight size={18} /></button></div>
            </>}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={orderOpen} onOpenChange={setOrderOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="dialog-overlay" />
          <Dialog.Content className="order-dialog glass-light" aria-describedby="order-description">
            <Dialog.Close className="dialog-close light-close" aria-label="Close order options"><X size={20} /></Dialog.Close>
            <Check className="order-check" size={29} />
            <Dialog.Title>Your sweet picks are ready.</Dialog.Title>
            <p id="order-description">Continue on a delivery platform to confirm live menu prices, availability and delivery details. Your preview bag will not transfer automatically.</p>
            <a className="button button-dark" href="https://www.zomato.com/mumbai/conical-gaufres-kandivali-west" target="_blank" rel="noreferrer">Order on Zomato <ArrowUpRight size={18} /></a>
            <a className="button button-outline-dark" href="https://www.swiggy.com/city/mumbai/conical-gaufres-mahavir-nagar-kandivali-west-rest500608" target="_blank" rel="noreferrer">Order on Swiggy <ArrowUpRight size={18} /></a>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <div className={`toast glass-dark ${notice ? 'visible' : ''}`} role="status" aria-live="polite"><Check size={17} />{notice}</div>
    </div>
  )
}
