# Asset credits

- Store details, dining offers and ratings reference the public Conical Gaufres Kandivali West listing on Zomato: https://www.zomato.com/mumbai/conical-gaufres-kandivali-west
- Product names, product photography, brand history and Wednesday promotion reference the official Conical Gaufres website: https://conicalgaufres.com/
- Product images were resized or cropped for this storefront concept. Rights remain with Conical Gaufres.
- Interface icons: Lucide (ISC License), via the installed lucide-react package.
- Typefaces: Instrument Serif and Manrope, served by Google Fonts (SIL Open Font License).
